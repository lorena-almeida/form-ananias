var emailRegex = /^[a-z0-9.]+@[a-z0-9]+\.[a-z]+\.([a-z]+)?$/i;

function validarNome() {
  let value = document.getElementById("nome").value;
  let re = /^[a-zA-ZéúíóáÉÚÍÓÁèùìòàçÇÈÙÌÒÀõãñÕÃÑêûîôâÊÛÎÔÂëÿüïöäËYÜÏÖÄ\-\ \s]+$/;
  if (!re.test(value)) {
    // campo inválido, retorna false para o formulário não ser submetido
    alert('Nome Inválido');
    document.form.nome.focus();
    return false;
  }
  return true;
}

function validarTelefone() {
  let value = document.getElementById("telefone").value;
  let re = /^(?:\+)[0-9]{2}\s?(?:\()[0-9]{2}(?:\))\s?[0-9]{4,5}(?:-)[0-9]{4}$/;
  if (! re.test(value)) {
    // campo inválido, retorna false para o formulário não ser submetido
    alert('Telefone Inválido, Tente colocar nesta ordem... 55 55 55555-5555');
    document.form.telefone.focus();
    return false;
  }
  return true;
}

function validarEmail() {
  let value = document.getElementById("emailRegex").value;
  let re = /^[a-z0-9.]+@[a-z0-9]+\.[a-z]+\.([a-z]+)?$/i;
  if (! re.test(value)) {
    // campo inválido, retorna false para o formulário não ser submetido
    alert('E-mail Inválido');
    document.form.email.focus();
    return false;
  }
  return true;
}
